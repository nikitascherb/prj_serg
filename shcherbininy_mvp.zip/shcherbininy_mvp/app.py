import os,sqlite3,secrets,csv,io
from datetime import datetime,timezone
from functools import wraps
from flask import Flask,render_template,request,redirect,url_for,session,flash,Response,abort
from werkzeug.security import check_password_hash,generate_password_hash
app=Flask(__name__)
app.secret_key=os.getenv('SECRET_KEY',secrets.token_hex(32))
DB=os.getenv('DATABASE_PATH',os.path.join(os.path.dirname(__file__),'requests.sqlite3'))
SERVICES={'strategy':'Стратегия и управление','product':'Продукты и бизнес-анализ','people':'Бизнес-психоаналитическое консультирование','legal':'Корпоративное право','marketing':'Маркетинг и digital'}
def conn():
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row;return c
def init_db():
 with conn() as c:
  c.execute('CREATE TABLE IF NOT EXISTS leads (id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, name TEXT NOT NULL, email TEXT NOT NULL, company TEXT, service TEXT NOT NULL, challenge TEXT NOT NULL, consent INTEGER NOT NULL, status TEXT NOT NULL DEFAULT "new", note TEXT NOT NULL DEFAULT "")')
init_db()
@app.get('/')
def home():return render_template('index.html',services=SERVICES)
@app.post('/request')
def new_request():
 if request.form.get('website'):return redirect('/thanks')
 name=request.form.get('name','').strip();email=request.form.get('email','').strip();company=request.form.get('company','').strip();service=request.form.get('service','');challenge=request.form.get('challenge','').strip()
 if not (2<=len(name)<=120 and '@' in email and len(email)<=200 and service in SERVICES and 10<=len(challenge)<=2500 and request.form.get('consent')=='yes'):
  flash('Проверьте обязательные поля и согласие на обработку данных.');return redirect('/#contact')
 with conn() as c:c.execute('INSERT INTO leads(created_at,name,email,company,service,challenge,consent) VALUES(?,?,?,?,?,?,1)',(datetime.now(timezone.utc).isoformat(),name,email,company[:200],service,challenge))
 return redirect('/thanks',code=303)
@app.get('/thanks')
def thanks():return render_template('thanks.html')
def auth(f):
 @wraps(f)
 def inner(*a,**kw):
  if not session.get('admin'):return redirect('/admin/login')
  return f(*a,**kw)
 return inner
@app.route('/admin/login',methods=['GET','POST'])
def login():
 if request.method=='POST':
  password=os.getenv('ADMIN_PASSWORD','')
  hashed=os.getenv('ADMIN_PASSWORD_HASH','')
  valid=(bool(hashed) and check_password_hash(hashed,request.form.get('password',''))) or (bool(password) and secrets.compare_digest(password,request.form.get('password','')))
  if valid:session.clear();session['admin']=True;return redirect('/admin')
  flash('Неверный пароль или ADMIN_PASSWORD не настроен.')
 return render_template('login.html')
@app.post('/admin/logout')
@auth
def logout():session.clear();return redirect('/')
@app.get('/admin')
@auth
def dashboard():
 with conn() as c:leads=c.execute('SELECT * FROM leads ORDER BY id DESC').fetchall()
 return render_template('admin.html',leads=leads,services=SERVICES)
@app.post('/admin/lead/<int:lead_id>')
@auth
def update(lead_id):
 status=request.form.get('status','new');note=request.form.get('note','')[:2000]
 if status not in ('new','in_progress','closed'):abort(400)
 with conn() as c:c.execute('UPDATE leads SET status=?,note=? WHERE id=?',(status,note,lead_id))
 return redirect('/admin')
@app.get('/admin/export.csv')
@auth
def export():
 output=io.StringIO();writer=csv.writer(output);writer.writerow(['ID','Дата','Имя','Email','Компания','Направление','Запрос','Статус','Заметка'])
 with conn() as c:
  for row in c.execute('SELECT id,created_at,name,email,company,service,challenge,status,note FROM leads ORDER BY id DESC'):
   writer.writerow([("'"+str(v) if str(v).startswith(('=','+','-','@')) else v) for v in row])
 return Response(output.getvalue(),mimetype='text/csv',headers={'Content-Disposition':'attachment; filename=leads.csv'})
@app.after_request
def headers(resp):
 resp.headers['X-Content-Type-Options']='nosniff';resp.headers['X-Frame-Options']='DENY';resp.headers['Referrer-Policy']='strict-origin-when-cross-origin';return resp
if __name__=='__main__':app.run(debug=False)
